function isFeatureCollection(json) {
  return json.type === "FeatureCollection";
}
function boundingBoxCall() {
  return fetch(
    "http://localhost:1234/mapsBoundingBox?lowerLatitude=-90&upperLatitude=90&lowerLongitude=-180&upperLongitude=180"
  ).then((r) => r.json()).then((response) => {
    let parseAnswer;
    var answer;
    answer = response.data;
    parseAnswer = JSON.parse(answer);
    return parseAnswer;
  });
}
export const featureData = {
  type: "FeatureCollection",
  features: (await boundingBoxCall()).features
};
export function overlayData() {
  console.log("feat: " + featureData.features);
  console.log(isFeatureCollection(featureData) ? featureData : void 0);
  return isFeatureCollection(featureData) ? featureData : void 0;
}
export const highlightLayer = {
  id: "highlight_data",
  type: "fill",
  paint: {
    "fill-color": "#000000",
    "fill-opacity": 0.2
  }
};
const propertyName = "holc_grade";
export const geoLayer = {
  id: "geo_data",
  type: "fill",
  paint: {
    "fill-color": [
      "match",
      ["get", propertyName],
      "A",
      "#5bcc04",
      "B",
      "#04b8cc",
      "C",
      "#e9ed0e",
      "D",
      "#d11d1d",
      "#ccc"
    ],
    "fill-opacity": 0.2
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm92ZXJsYXlzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZlYXR1cmVDb2xsZWN0aW9uIH0gZnJvbSBcImdlb2pzb25cIjtcbmltcG9ydCB7IEZpbGxMYXllciB9IGZyb20gXCJyZWFjdC1tYXAtZ2xcIjtcblxuZnVuY3Rpb24gaXNGZWF0dXJlQ29sbGVjdGlvbihqc29uOiBhbnkpOiBqc29uIGlzIEZlYXR1cmVDb2xsZWN0aW9uIHtcbiAgcmV0dXJuIGpzb24udHlwZSA9PT0gXCJGZWF0dXJlQ29sbGVjdGlvblwiO1xufVxuXG5cbmZ1bmN0aW9uIGJvdW5kaW5nQm94Q2FsbCgpOiBQcm9taXNlPEdlb0pTT04uRmVhdHVyZUNvbGxlY3Rpb24+IHtcbiAgcmV0dXJuIGZldGNoKFxuICAgIFwiaHR0cDovL2xvY2FsaG9zdDoxMjM0L21hcHNCb3VuZGluZ0JveD9sb3dlckxhdGl0dWRlPS05MCZ1cHBlckxhdGl0dWRlPTkwJmxvd2VyTG9uZ2l0dWRlPS0xODAmdXBwZXJMb25naXR1ZGU9MTgwXCJcbiAgKVxuICAgIC50aGVuKChyKSA9PiByLmpzb24oKSlcbiAgICAudGhlbigocmVzcG9uc2UpID0+IHtcbiAgICAgIGxldCBwYXJzZUFuc3dlcjogR2VvSlNPTi5GZWF0dXJlQ29sbGVjdGlvbjtcbiAgICAgIHZhciBhbnN3ZXI7XG4gICAgICBhbnN3ZXIgPSByZXNwb25zZS5kYXRhXG4gICAgICBwYXJzZUFuc3dlciA9IEpTT04ucGFyc2UoYW5zd2VyKVxuICAgICAgcmV0dXJuIHBhcnNlQW5zd2VyO1xuICAgIH0pO1xufVxuXG5leHBvcnQgY29uc3QgZmVhdHVyZURhdGE6IEdlb0pTT04uRmVhdHVyZUNvbGxlY3Rpb24gPSB7XG4gIHR5cGU6IFwiRmVhdHVyZUNvbGxlY3Rpb25cIixcbiAgZmVhdHVyZXM6IChhd2FpdCBib3VuZGluZ0JveENhbGwoKSkuZmVhdHVyZXMsXG59O1xuXG4gZXhwb3J0IGZ1bmN0aW9uIG92ZXJsYXlEYXRhKCkge1xuICBjb25zb2xlLmxvZyhcImZlYXQ6IFwiICsgZmVhdHVyZURhdGEuZmVhdHVyZXMpXG4gIGNvbnNvbGUubG9nKGlzRmVhdHVyZUNvbGxlY3Rpb24oZmVhdHVyZURhdGEpID8gZmVhdHVyZURhdGEgOiB1bmRlZmluZWQpXG4gIHJldHVybiBpc0ZlYXR1cmVDb2xsZWN0aW9uKGZlYXR1cmVEYXRhKSA/IGZlYXR1cmVEYXRhIDogdW5kZWZpbmVkO1xufVxuXG5leHBvcnQgY29uc3QgaGlnaGxpZ2h0TGF5ZXI6IEZpbGxMYXllciA9IHtcbiAgaWQ6IFwiaGlnaGxpZ2h0X2RhdGFcIixcbiAgdHlwZTogXCJmaWxsXCIsXG4gIHBhaW50OiB7XG4gICAgXCJmaWxsLWNvbG9yXCI6IFwiIzAwMDAwMFwiLFxuICAgIFwiZmlsbC1vcGFjaXR5XCI6IDAuMixcblxuICB9LFxufTtcblxuXG5jb25zdCBwcm9wZXJ0eU5hbWUgPSBcImhvbGNfZ3JhZGVcIjtcbmV4cG9ydCBjb25zdCBnZW9MYXllcjogRmlsbExheWVyID0ge1xuICBpZDogXCJnZW9fZGF0YVwiLFxuICB0eXBlOiBcImZpbGxcIixcbiAgcGFpbnQ6IHtcbiAgICBcImZpbGwtY29sb3JcIjogW1xuICAgICAgXCJtYXRjaFwiLFxuICAgICAgW1wiZ2V0XCIsIHByb3BlcnR5TmFtZV0sXG4gICAgICBcIkFcIixcbiAgICAgIFwiIzViY2MwNFwiLFxuICAgICAgXCJCXCIsXG4gICAgICBcIiMwNGI4Y2NcIixcbiAgICAgIFwiQ1wiLFxuICAgICAgXCIjZTllZDBlXCIsXG4gICAgICBcIkRcIixcbiAgICAgIFwiI2QxMWQxZFwiLFxuICAgICAgXCIjY2NjXCIsXG4gICAgXSxcbiAgICBcImZpbGwtb3BhY2l0eVwiOiAwLjIsXG4gIH0sXG59O1xuIl0sIm1hcHBpbmdzIjoiQUFHQSxTQUFTLG9CQUFvQixNQUFzQztBQUNqRSxTQUFPLEtBQUssU0FBUztBQUN2QjtBQUdBLFNBQVMsa0JBQXNEO0FBQzdELFNBQU87QUFBQSxJQUNMO0FBQUEsRUFDRixFQUNHLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQ3BCLEtBQUssQ0FBQyxhQUFhO0FBQ2xCLFFBQUk7QUFDSixRQUFJO0FBQ0osYUFBUyxTQUFTO0FBQ2xCLGtCQUFjLEtBQUssTUFBTSxNQUFNO0FBQy9CLFdBQU87QUFBQSxFQUNULENBQUM7QUFDTDtBQUVPLGFBQU0sY0FBeUM7QUFBQSxFQUNwRCxNQUFNO0FBQUEsRUFDTixXQUFXLE1BQU0sZ0JBQWdCLEdBQUc7QUFDdEM7QUFFUSxnQkFBUyxjQUFjO0FBQzdCLFVBQVEsSUFBSSxXQUFXLFlBQVksUUFBUTtBQUMzQyxVQUFRLElBQUksb0JBQW9CLFdBQVcsSUFBSSxjQUFjLE1BQVM7QUFDdEUsU0FBTyxvQkFBb0IsV0FBVyxJQUFJLGNBQWM7QUFDMUQ7QUFFTyxhQUFNLGlCQUE0QjtBQUFBLEVBQ3ZDLElBQUk7QUFBQSxFQUNKLE1BQU07QUFBQSxFQUNOLE9BQU87QUFBQSxJQUNMLGNBQWM7QUFBQSxJQUNkLGdCQUFnQjtBQUFBLEVBRWxCO0FBQ0Y7QUFHQSxNQUFNLGVBQWU7QUFDZCxhQUFNLFdBQXNCO0FBQUEsRUFDakMsSUFBSTtBQUFBLEVBQ0osTUFBTTtBQUFBLEVBQ04sT0FBTztBQUFBLElBQ0wsY0FBYztBQUFBLE1BQ1o7QUFBQSxNQUNBLENBQUMsT0FBTyxZQUFZO0FBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxJQUNBLGdCQUFnQjtBQUFBLEVBQ2xCO0FBQ0Y7IiwibmFtZXMiOltdfQ==