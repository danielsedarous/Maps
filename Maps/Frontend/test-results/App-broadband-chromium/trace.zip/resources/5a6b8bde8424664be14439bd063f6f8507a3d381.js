import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/MapBox.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Map, { Layer, Source } from "/node_modules/.vite/deps/react-map-gl.js?v=d07f8812";
import { geoLayer, highlightLayer, overlayData, featureData } from "/src/overlays.ts";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=d07f8812"; const useState = __vite__cjsImport5_react["useState"]; const useEffect = __vite__cjsImport5_react["useEffect"];
import { Access_Token } from "/src/private/api.ts";
function MapBox(props) {
  _s();
  const initialZoom = 10;
  function onMapClick(e) {
    console.log(e.lngLat.lat);
    console.log(e.lngLat.lng);
  }
  const [viewState, setViewState] = useState({});
  const highlightData = {
    type: "FeatureCollection",
    features: props.highlightResult
  };
  const [overlay, setOverlay] = useState(void 0);
  useEffect(() => {
    setOverlay(overlayData());
  }, [props.highlightResult]);
  return /* @__PURE__ */ jsxDEV(Map, { mapboxAccessToken: Access_Token, ...viewState, onMove: (ev) => setViewState(ev.viewState), style: {
    width: window.innerWidth,
    height: window.innerHeight
  }, mapStyle: "mapbox://styles/mapbox/streets-v12", onClick: (ev) => onMapClick(ev), children: [
    /* @__PURE__ */ jsxDEV(Source, { id: "geo_data", type: "geojson", data: featureData, children: /* @__PURE__ */ jsxDEV(Layer, { ...geoLayer }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx",
      lineNumber: 41,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Source, { id: "highlight", type: "geojson", data: highlightData, children: /* @__PURE__ */ jsxDEV(Layer, { ...highlightLayer }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx",
      lineNumber: 44,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx",
      lineNumber: 43,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx",
    lineNumber: 36,
    columnNumber: 10
  }, this);
}
_s(MapBox, "Aa90zDODiS8etEZvNGVv79uyv88=");
_c = MapBox;
export default MapBox;
var _c;
$RefreshReg$(_c, "MapBox");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURROzs7Ozs7Ozs7Ozs7Ozs7O0FBdkRSLE9BQU9BLE9BQU9DLE9BQTJCQyxjQUFjO0FBQ3ZELFNBQVNDLFVBQVVDLGdCQUFnQkMsYUFBYUMsbUJBQW1CO0FBQ25FLFNBQTBDQyxVQUFVQyxpQkFBaUI7QUFDckUsU0FBU0Msb0JBQW9CO0FBbUI3QixTQUFTQyxPQUFPQyxPQUFvQjtBQUFBQyxLQUFBO0FBQ2xDLFFBQU1DLGNBQWM7QUFFcEIsV0FBU0MsV0FBV0MsR0FBdUI7QUFDekNDLFlBQVFDLElBQUlGLEVBQUVHLE9BQU9DLEdBQUc7QUFDeEJILFlBQVFDLElBQUlGLEVBQUVHLE9BQU9FLEdBQUc7QUFBQSxFQUMxQjtBQUVBLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJZixTQUFTLENBQUMsQ0FBQztBQUU3QyxRQUFNZ0IsZ0JBQTJDO0FBQUEsSUFDL0NDLE1BQU07QUFBQSxJQUNOQyxVQUFVZCxNQUFNZTtBQUFBQSxFQUNsQjtBQUVBLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJckIsU0FDNUJzQixNQUNGO0FBRUFyQixZQUFVLE1BQU07QUFDZG9CLGVBQVd2QixZQUFZLENBQUM7QUFBQSxFQUMxQixHQUFHLENBQUNNLE1BQU1lLGVBQWUsQ0FBQztBQUUxQixTQUNFLHVCQUFDLE9BQ0MsbUJBQW1CakIsY0FDbkIsR0FBSVksV0FDSixRQUFTUyxRQUFPUixhQUFhUSxHQUFHVCxTQUFTLEdBQ3pDLE9BQU87QUFBQSxJQUFFVSxPQUFPQyxPQUFPQztBQUFBQSxJQUFZQyxRQUFRRixPQUFPRztBQUFBQSxFQUFZLEdBQzlELFVBQVUsc0NBQ1YsU0FBUyxDQUFDTCxPQUEyQmhCLFdBQVdnQixFQUFFLEdBRWxEO0FBQUEsMkJBQUMsVUFBTyxJQUFHLFlBQVcsTUFBSyxXQUFVLE1BQU14QixhQUN6QyxpQ0FBQyxTQUFNLEdBQUlILFlBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQixLQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFVBQU8sSUFBRyxhQUFZLE1BQUssV0FBVSxNQUFNb0IsZUFDMUMsaUNBQUMsU0FBTSxHQUFJbkIsa0JBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQixLQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FjQTtBQUVKO0FBQUNRLEdBeENRRixRQUFNO0FBQUEwQixLQUFOMUI7QUEwQ1QsZUFBZUE7QUFBTyxJQUFBMEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk1hcCIsIkxheWVyIiwiU291cmNlIiwiZ2VvTGF5ZXIiLCJoaWdobGlnaHRMYXllciIsIm92ZXJsYXlEYXRhIiwiZmVhdHVyZURhdGEiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkFjY2Vzc19Ub2tlbiIsIk1hcEJveCIsInByb3BzIiwiX3MiLCJpbml0aWFsWm9vbSIsIm9uTWFwQ2xpY2siLCJlIiwiY29uc29sZSIsImxvZyIsImxuZ0xhdCIsImxhdCIsImxuZyIsInZpZXdTdGF0ZSIsInNldFZpZXdTdGF0ZSIsImhpZ2hsaWdodERhdGEiLCJ0eXBlIiwiZmVhdHVyZXMiLCJoaWdobGlnaHRSZXN1bHQiLCJvdmVybGF5Iiwic2V0T3ZlcmxheSIsInVuZGVmaW5lZCIsImV2Iiwid2lkdGgiLCJ3aW5kb3ciLCJpbm5lcldpZHRoIiwiaGVpZ2h0IiwiaW5uZXJIZWlnaHQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1hcEJveC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IE1hcCwgeyBMYXllciwgTWFwTGF5ZXJNb3VzZUV2ZW50LCBTb3VyY2UgfSBmcm9tIFwicmVhY3QtbWFwLWdsXCI7XG5pbXBvcnQgeyBnZW9MYXllciwgaGlnaGxpZ2h0TGF5ZXIsIG92ZXJsYXlEYXRhLCBmZWF0dXJlRGF0YSB9IGZyb20gXCIuL292ZXJsYXlzXCI7XG5pbXBvcnQgUmVhY3QsIHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBBY2Nlc3NfVG9rZW4gfSBmcm9tIFwiLi9wcml2YXRlL2FwaS5qc1wiO1xuXG4vKipcbiAqIGRlZmluZXMgcHJvcHMgZm9yIHZhbHVlcyB0aGF0IG5lZWQgdG8gYmUgYWNjZXNzZWQgYW5kIHVwZGF0ZWQgYWNyb3NzIGNsYXNzZXNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNYXBCb3hQcm9wcyB7XG4gIGhpZ2hsaWdodFJlc3VsdDogR2VvSlNPTi5GZWF0dXJlW107XG4gIHNldEhpZ2hsaWdodFJlc3VsdDogRGlzcGF0Y2g8XG4gICAgU2V0U3RhdGVBY3Rpb248XG4gICAgICBHZW9KU09OLkZlYXR1cmU8R2VvSlNPTi5HZW9tZXRyeSwgR2VvSlNPTi5HZW9Kc29uUHJvcGVydGllcz5bXVxuICAgID5cbiAgPjtcbn1cblxuLyoqXG4gKiBkZWZpbmVzIG1hcGJveCBmdW5jdGlvbnMgYW5kIHZhbHVlcyBsaWtlIHNldHRpbmcgaGlnaGxpZ2h0aW5nIGZvciByZWRsaW5pbmcgYW5kIGFyZWEgc2VhcmNoZXNcbiAqIEBwYXJhbSBwcm9wc1xuICogQHJldHVybnNcbiAqL1xuZnVuY3Rpb24gTWFwQm94KHByb3BzOiBNYXBCb3hQcm9wcykge1xuICBjb25zdCBpbml0aWFsWm9vbSA9IDEwO1xuXG4gIGZ1bmN0aW9uIG9uTWFwQ2xpY2soZTogTWFwTGF5ZXJNb3VzZUV2ZW50KSB7XG4gICAgY29uc29sZS5sb2coZS5sbmdMYXQubGF0KTtcbiAgICBjb25zb2xlLmxvZyhlLmxuZ0xhdC5sbmcpO1xuICB9XG5cbiAgY29uc3QgW3ZpZXdTdGF0ZSwgc2V0Vmlld1N0YXRlXSA9IHVzZVN0YXRlKHt9KTtcblxuICBjb25zdCBoaWdobGlnaHREYXRhOiBHZW9KU09OLkZlYXR1cmVDb2xsZWN0aW9uID0ge1xuICAgIHR5cGU6IFwiRmVhdHVyZUNvbGxlY3Rpb25cIixcbiAgICBmZWF0dXJlczogcHJvcHMuaGlnaGxpZ2h0UmVzdWx0LFxuICB9O1xuXG4gIGNvbnN0IFtvdmVybGF5LCBzZXRPdmVybGF5XSA9IHVzZVN0YXRlPEdlb0pTT04uRmVhdHVyZUNvbGxlY3Rpb24gfCB1bmRlZmluZWQ+KFxuICAgIHVuZGVmaW5lZFxuICApO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0T3ZlcmxheShvdmVybGF5RGF0YSgpKTtcbiAgfSwgW3Byb3BzLmhpZ2hsaWdodFJlc3VsdF0pO1xuXG4gIHJldHVybiAoXG4gICAgPE1hcFxuICAgICAgbWFwYm94QWNjZXNzVG9rZW49e0FjY2Vzc19Ub2tlbn1cbiAgICAgIHsuLi52aWV3U3RhdGV9XG4gICAgICBvbk1vdmU9eyhldikgPT4gc2V0Vmlld1N0YXRlKGV2LnZpZXdTdGF0ZSl9XG4gICAgICBzdHlsZT17eyB3aWR0aDogd2luZG93LmlubmVyV2lkdGgsIGhlaWdodDogd2luZG93LmlubmVySGVpZ2h0IH19XG4gICAgICBtYXBTdHlsZT17XCJtYXBib3g6Ly9zdHlsZXMvbWFwYm94L3N0cmVldHMtdjEyXCJ9XG4gICAgICBvbkNsaWNrPXsoZXY6IE1hcExheWVyTW91c2VFdmVudCkgPT4gb25NYXBDbGljayhldil9XG4gICAgPlxuICAgICAgPFNvdXJjZSBpZD1cImdlb19kYXRhXCIgdHlwZT1cImdlb2pzb25cIiBkYXRhPXtmZWF0dXJlRGF0YX0+XG4gICAgICAgIDxMYXllciB7Li4uZ2VvTGF5ZXJ9IC8+XG4gICAgICA8L1NvdXJjZT5cbiAgICAgIDxTb3VyY2UgaWQ9XCJoaWdobGlnaHRcIiB0eXBlPVwiZ2VvanNvblwiIGRhdGE9e2hpZ2hsaWdodERhdGF9PlxuICAgICAgICA8TGF5ZXIgey4uLmhpZ2hsaWdodExheWVyfSAvPlxuICAgICAgPC9Tb3VyY2U+XG4gICAgPC9NYXA+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IE1hcEJveDtcbiJdLCJmaWxlIjoiL1VzZXJzL2ZyYW5jZXNjYWVsaWEvRG9jdW1lbnRzL0NTMzIvbWFwcy1kc2VkYXJvdS1mZWxpYS9NYXBzL0Zyb250ZW5kL3NyYy9NYXBCb3gudHN4In0=