import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/App.css";
import REPL from "/src/REPL.tsx?t=1699810098243";
function App() {
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: /* @__PURE__ */ jsxDEV("div", { className: "repl-container", children: /* @__PURE__ */ jsxDEV(REPL, {}, void 0, false, {
    fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/App.tsx",
    lineNumber: 6,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/App.tsx",
    lineNumber: 5,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/App.tsx",
    lineNumber: 4,
    columnNumber: 10
  }, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1E7QUFQUixPQUFPLG9CQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNsQixPQUFPQSxVQUFVO0FBRWpCLFNBQVNDLE1BQU07QUFDYixTQUNFLHVCQUFDLFNBQUksV0FBVSxPQUNiLGlDQUFDLFNBQUksV0FBVSxrQkFDYixpQ0FBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBSyxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQTtBQUVKO0FBQUNDLEtBUlFEO0FBVVQsZUFBZUE7QUFBSSxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUkVQTCIsIkFwcCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuL0FwcC5jc3NcIjtcbmltcG9ydCBSRVBMIGZyb20gXCIuL1JFUExcIjtcblxuZnVuY3Rpb24gQXBwKCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiQXBwXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtY29udGFpbmVyXCI+XG4gICAgICAgIDxSRVBMIC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwOyJdLCJmaWxlIjoiL1VzZXJzL2ZyYW5jZXNjYWVsaWEvRG9jdW1lbnRzL0NTMzIvbWFwcy1kc2VkYXJvdS1mZWxpYS9NYXBzL0Zyb250ZW5kL3NyYy9BcHAudHN4In0=