import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/MapBox.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Map, { Layer, Source } from "/node_modules/.vite/deps/react-map-gl.js?v=d07f8812";
import { geoLayer, highlightLayer, overlayData, featureData } from "/src/overlays.ts";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=d07f8812"; const useState = __vite__cjsImport5_react["useState"]; const useEffect = __vite__cjsImport5_react["useEffect"];
import { Access_Token } from "/src/private/api.ts";
function MapBox(props) {
  _s();
  const initialZoom = 10;
  function onMapClick(e) {
    console.log(e.lngLat.lat);
    console.log(e.lngLat.lng);
  }
  const [viewState, setViewState] = useState({
    // longitude: ProvidenceLatLong.long,
    // latitude: ProvidenceLatLong.lat,
    // zoom: initialZoom,
  });
  const highlightData = {
    type: "FeatureCollection",
    features: props.highlightResult
  };
  const [overlay, setOverlay] = useState(void 0);
  useEffect(() => {
    setOverlay(overlayData());
    console.log("overlay" + overlay);
    console.log("featureData: " + featureData.features);
    console.log("featureType: " + featureData.type);
  }, [props.highlightResult]);
  return /* @__PURE__ */ jsxDEV(Map, { mapboxAccessToken: Access_Token, ...viewState, onMove: (ev) => setViewState(ev.viewState), style: {
    width: window.innerWidth,
    height: window.innerHeight
  }, mapStyle: "mapbox://styles/mapbox/streets-v12", onClick: (ev) => onMapClick(ev), children: [
    /* @__PURE__ */ jsxDEV(Source, { id: "geo_data", type: "geojson", data: featureData, children: /* @__PURE__ */ jsxDEV(Layer, { ...geoLayer }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx",
      lineNumber: 47,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Source, { id: "highlight", type: "geojson", data: highlightData, children: /* @__PURE__ */ jsxDEV(Layer, { ...highlightLayer }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx",
      lineNumber: 50,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx",
      lineNumber: 49,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx",
    lineNumber: 42,
    columnNumber: 10
  }, this);
}
_s(MapBox, "5j6WO43bA7k4KaMwHj9sVyEExds=");
_c = MapBox;
export default MapBox;
var _c;
$RefreshReg$(_c, "MapBox");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/MapBox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0VROzs7Ozs7Ozs7Ozs7Ozs7O0FBaEVSLE9BQU9BLE9BQU9DLE9BQTJCQyxjQUFjO0FBQ3ZELFNBQVNDLFVBQVVDLGdCQUFnQkMsYUFBYUMsbUJBQWtCO0FBQ2xFLFNBQTBDQyxVQUFVQyxpQkFBaUI7QUFDckUsU0FBU0Msb0JBQW9CO0FBZTdCLFNBQVNDLE9BQU9DLE9BQW9CO0FBQUFDLEtBQUE7QUFDbEMsUUFBTUMsY0FBYztBQUVwQixXQUFTQyxXQUFXQyxHQUF1QjtBQUN6Q0MsWUFBUUMsSUFBSUYsRUFBRUcsT0FBT0MsR0FBRztBQUN4QkgsWUFBUUMsSUFBSUYsRUFBRUcsT0FBT0UsR0FBRztBQUFBLEVBQzFCO0FBRUEsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlmLFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUd6QyxDQUNEO0FBRUQsUUFBTWdCLGdCQUEyQztBQUFBLElBQy9DQyxNQUFNO0FBQUEsSUFDTkMsVUFBVWQsTUFBTWU7QUFBQUEsRUFDbEI7QUFFRSxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSXJCLFNBRTVCc0IsTUFBUztBQUdickIsWUFBVSxNQUFNO0FBQ2RvQixlQUFXdkIsWUFBWSxDQUFDO0FBQ3hCVyxZQUFRQyxJQUFJLFlBQVlVLE9BQU87QUFDL0JYLFlBQVFDLElBQUksa0JBQWtCWCxZQUFZbUIsUUFBUTtBQUNsRFQsWUFBUUMsSUFBSSxrQkFBa0JYLFlBQVlrQixJQUFJO0FBQUEsRUFFaEQsR0FBRyxDQUFDYixNQUFNZSxlQUFlLENBQUM7QUFNMUIsU0FDRSx1QkFBQyxPQUNDLG1CQUFtQmpCLGNBQ25CLEdBQUlZLFdBQ0osUUFBU1MsUUFBT1IsYUFBYVEsR0FBR1QsU0FBUyxHQUN6QyxPQUFPO0FBQUEsSUFBRVUsT0FBT0MsT0FBT0M7QUFBQUEsSUFBWUMsUUFBUUYsT0FBT0c7QUFBQUEsRUFBWSxHQUM5RCxVQUFVLHNDQUNWLFNBQVMsQ0FBQ0wsT0FBMkJoQixXQUFXZ0IsRUFBRSxHQUVsRDtBQUFBLDJCQUFDLFVBQU8sSUFBRyxZQUFXLE1BQUssV0FBVSxNQUFNeEIsYUFDekMsaUNBQUMsU0FBTSxHQUFJSCxZQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0IsS0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxVQUFPLElBQUcsYUFBWSxNQUFLLFdBQVUsTUFBTW9CLGVBQzFDLGlDQUFDLFNBQU0sR0FBSW5CLGtCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEIsS0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBY0E7QUFFSjtBQUFDUSxHQXJEUUYsUUFBTTtBQUFBMEIsS0FBTjFCO0FBdURULGVBQWVBO0FBQU8sSUFBQTBCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJNYXAiLCJMYXllciIsIlNvdXJjZSIsImdlb0xheWVyIiwiaGlnaGxpZ2h0TGF5ZXIiLCJvdmVybGF5RGF0YSIsImZlYXR1cmVEYXRhIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJBY2Nlc3NfVG9rZW4iLCJNYXBCb3giLCJwcm9wcyIsIl9zIiwiaW5pdGlhbFpvb20iLCJvbk1hcENsaWNrIiwiZSIsImNvbnNvbGUiLCJsb2ciLCJsbmdMYXQiLCJsYXQiLCJsbmciLCJ2aWV3U3RhdGUiLCJzZXRWaWV3U3RhdGUiLCJoaWdobGlnaHREYXRhIiwidHlwZSIsImZlYXR1cmVzIiwiaGlnaGxpZ2h0UmVzdWx0Iiwib3ZlcmxheSIsInNldE92ZXJsYXkiLCJ1bmRlZmluZWQiLCJldiIsIndpZHRoIiwid2luZG93IiwiaW5uZXJXaWR0aCIsImhlaWdodCIsImlubmVySGVpZ2h0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJNYXBCb3gudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBNYXAsIHsgTGF5ZXIsIE1hcExheWVyTW91c2VFdmVudCwgU291cmNlIH0gZnJvbSBcInJlYWN0LW1hcC1nbFwiO1xuaW1wb3J0IHsgZ2VvTGF5ZXIsIGhpZ2hsaWdodExheWVyLCBvdmVybGF5RGF0YSwgZmVhdHVyZURhdGF9IGZyb20gXCIuL292ZXJsYXlzXCI7XG5pbXBvcnQgUmVhY3QsIHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBBY2Nlc3NfVG9rZW4gfSBmcm9tIFwiLi9wcml2YXRlL2FwaS5qc1wiO1xuXG5leHBvcnQgaW50ZXJmYWNlIE1hcEJveFByb3BzIHtcbiAgaGlnaGxpZ2h0UmVzdWx0OiBHZW9KU09OLkZlYXR1cmVbXTtcbiAgc2V0SGlnaGxpZ2h0UmVzdWx0OiBEaXNwYXRjaDxcbiAgICBTZXRTdGF0ZUFjdGlvbjxcbiAgICAgIEdlb0pTT04uRmVhdHVyZTxHZW9KU09OLkdlb21ldHJ5LCBHZW9KU09OLkdlb0pzb25Qcm9wZXJ0aWVzPltdXG4gICAgPlxuICA+O1xufVxuaW50ZXJmYWNlIExhdExvbmcge1xuICBsYXQ6IG51bWJlcjtcbiAgbG9uZzogbnVtYmVyO1xufVxuXG5mdW5jdGlvbiBNYXBCb3gocHJvcHM6IE1hcEJveFByb3BzKSB7XG4gIGNvbnN0IGluaXRpYWxab29tID0gMTA7XG5cbiAgZnVuY3Rpb24gb25NYXBDbGljayhlOiBNYXBMYXllck1vdXNlRXZlbnQpIHtcbiAgICBjb25zb2xlLmxvZyhlLmxuZ0xhdC5sYXQpO1xuICAgIGNvbnNvbGUubG9nKGUubG5nTGF0LmxuZyk7XG4gIH1cblxuICBjb25zdCBbdmlld1N0YXRlLCBzZXRWaWV3U3RhdGVdID0gdXNlU3RhdGUoe1xuICAgIC8vIGxvbmdpdHVkZTogUHJvdmlkZW5jZUxhdExvbmcubG9uZyxcbiAgICAvLyBsYXRpdHVkZTogUHJvdmlkZW5jZUxhdExvbmcubGF0LFxuICAgIC8vIHpvb206IGluaXRpYWxab29tLFxuICB9KTtcblxuICBjb25zdCBoaWdobGlnaHREYXRhOiBHZW9KU09OLkZlYXR1cmVDb2xsZWN0aW9uID0ge1xuICAgIHR5cGU6IFwiRmVhdHVyZUNvbGxlY3Rpb25cIixcbiAgICBmZWF0dXJlczogcHJvcHMuaGlnaGxpZ2h0UmVzdWx0LFxuICB9O1xuXG4gICAgY29uc3QgW292ZXJsYXksIHNldE92ZXJsYXldID0gdXNlU3RhdGU8XG4gICAgICBHZW9KU09OLkZlYXR1cmVDb2xsZWN0aW9uIHwgdW5kZWZpbmVkXG4gICAgPih1bmRlZmluZWQpO1xuXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRPdmVybGF5KG92ZXJsYXlEYXRhKCkpO1xuICAgIGNvbnNvbGUubG9nKFwib3ZlcmxheVwiICsgb3ZlcmxheSlcbiAgICBjb25zb2xlLmxvZyhcImZlYXR1cmVEYXRhOiBcIiArIGZlYXR1cmVEYXRhLmZlYXR1cmVzKTtcbiAgICBjb25zb2xlLmxvZyhcImZlYXR1cmVUeXBlOiBcIiArIGZlYXR1cmVEYXRhLnR5cGUpO1xuXG4gIH0sIFtwcm9wcy5oaWdobGlnaHRSZXN1bHRdKTtcblxuICAvLyBmdW5jdGlvbiBnZXRCb3VuZGluZ0JveERhdGEoKTogR2VvSlNPTi5GZWF0dXJlQ29sbGVjdGlvbiB8IHVuZGVmaW5lZCB7XG4gIC8vICAgcmV0dXJuIG92ZXJsYXlEYXRhKCk7XG4gIC8vIH1cblxuICByZXR1cm4gKFxuICAgIDxNYXBcbiAgICAgIG1hcGJveEFjY2Vzc1Rva2VuPXtBY2Nlc3NfVG9rZW59XG4gICAgICB7Li4udmlld1N0YXRlfVxuICAgICAgb25Nb3ZlPXsoZXYpID0+IHNldFZpZXdTdGF0ZShldi52aWV3U3RhdGUpfVxuICAgICAgc3R5bGU9e3sgd2lkdGg6IHdpbmRvdy5pbm5lcldpZHRoLCBoZWlnaHQ6IHdpbmRvdy5pbm5lckhlaWdodCB9fVxuICAgICAgbWFwU3R5bGU9e1wibWFwYm94Oi8vc3R5bGVzL21hcGJveC9zdHJlZXRzLXYxMlwifVxuICAgICAgb25DbGljaz17KGV2OiBNYXBMYXllck1vdXNlRXZlbnQpID0+IG9uTWFwQ2xpY2soZXYpfVxuICAgID5cbiAgICAgIDxTb3VyY2UgaWQ9XCJnZW9fZGF0YVwiIHR5cGU9XCJnZW9qc29uXCIgZGF0YT17ZmVhdHVyZURhdGF9PlxuICAgICAgICA8TGF5ZXIgey4uLmdlb0xheWVyfSAvPlxuICAgICAgPC9Tb3VyY2U+XG4gICAgICA8U291cmNlIGlkPVwiaGlnaGxpZ2h0XCIgdHlwZT1cImdlb2pzb25cIiBkYXRhPXtoaWdobGlnaHREYXRhfT5cbiAgICAgICAgPExheWVyIHsuLi5oaWdobGlnaHRMYXllcn0gLz5cbiAgICAgIDwvU291cmNlPlxuICAgIDwvTWFwPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBNYXBCb3g7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9mcmFuY2VzY2FlbGlhL0RvY3VtZW50cy9DUzMyL21hcHMtZHNlZGFyb3UtZmVsaWEvTWFwcy9Gcm9udGVuZC9zcmMvTWFwQm94LnRzeCJ9