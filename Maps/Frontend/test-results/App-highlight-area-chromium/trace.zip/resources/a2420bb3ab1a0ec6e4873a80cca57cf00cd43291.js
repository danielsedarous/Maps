import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/REPLHistory.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/main.css";
export function REPLHistory(props) {
  return /* @__PURE__ */ jsxDEV("div", { id: "replHistoryId", className: "repl-history", "aria-live": "polite", "aria-atomic": "true", "aria-a": true, "aria-label": "Past commands", children: props.history.map((command, index) => /* @__PURE__ */ jsxDEV("p", { children: command }, void 0, false, {
    fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLHistory.tsx",
    lineNumber: 23,
    columnNumber: 46
  }, this)) }, void 0, false, {
    fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLHistory.tsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JRO0FBeEJSLE9BQU8sb0JBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBb0JaLGdCQUFTQSxZQUFZQyxPQUF5QjtBQUNuRCxTQUNFLHVCQUFDLFNBQUksSUFBRyxpQkFBZ0IsV0FBVSxnQkFBZSxhQUFVLFVBQVMsZUFBWSxRQUFPLFVBQU0sTUFBQyxjQUFXLGlCQUN0R0EsZ0JBQU1DLFFBQVFDLElBQUksQ0FBQ0MsU0FBU0MsVUFDM0IsdUJBQUMsT0FBR0QscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFZLENBQ2IsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFFSjtBQUFDRSxLQVJlTjtBQUFXLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSRVBMSGlzdG9yeSIsInByb3BzIiwiaGlzdG9yeSIsIm1hcCIsImNvbW1hbmQiLCJpbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTEhpc3RvcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4vbWFpbi5jc3NcIjtcbmltcG9ydCB7IERpc3BhdGNoLCBSZWFjdEVsZW1lbnQsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG4vKipcbiAqIEhlcmUsIHdlIHNldCB1cCBhbmQgZGlzcGxheSB0aGUgY29tbWFuZCBoaXN0b3J5IHRob3VnaCBSZWFjdCBjb21wb25lbnRzXG4gKiBzdG9yZWQgaW4gYW4gYXJyYXkgY2FsbGVkIGhpc3RvcnkuIFRoZXNlIGNvbXBvbmVudHMgYXJlIGNyZWF0ZWQgaW4gXG4gKiBSRVBMSW5wdXQuXG4gKi9cblxuaW50ZXJmYWNlIFJFUExIaXN0b3J5UHJvcHMge1xuICBoaXN0b3J5OiBSZWFjdEVsZW1lbnRbXTtcbn1cblxuLyoqXG4gKiBUaGlzIGZ1bmN0aW9uIGRpc3BsYXlzIGVhY2ggUmVhY3QgY29tcG9uZW50IGtlcHQgaW4gdGhlIGhpc3RvcnkgYXJyYXkgXG4gKiBpbiB0aGUgUkVQTCBoaXN0b3J5IGJveC5cbiAqIEBwYXJhbSBwcm9wcyBcbiAqIEByZXR1cm5zIFxuICovXG5cbmV4cG9ydCBmdW5jdGlvbiBSRVBMSGlzdG9yeShwcm9wczogUkVQTEhpc3RvcnlQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxkaXYgaWQ9XCJyZXBsSGlzdG9yeUlkXCIgY2xhc3NOYW1lPVwicmVwbC1oaXN0b3J5XCIgYXJpYS1saXZlPVwicG9saXRlXCIgYXJpYS1hdG9taWM9XCJ0cnVlXCIgYXJpYS1hIGFyaWEtbGFiZWw9XCJQYXN0IGNvbW1hbmRzXCI+XG4gICAgICB7cHJvcHMuaGlzdG9yeS5tYXAoKGNvbW1hbmQsIGluZGV4KSA9PiAoXG4gICAgICAgIDxwPntjb21tYW5kfTwvcD5cbiAgICAgICkpfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZnJhbmNlc2NhZWxpYS9Eb2N1bWVudHMvQ1MzMi9tYXBzLWRzZWRhcm91LWZlbGlhL01hcHMvRnJvbnRlbmQvc3JjL1JFUExIaXN0b3J5LnRzeCJ9