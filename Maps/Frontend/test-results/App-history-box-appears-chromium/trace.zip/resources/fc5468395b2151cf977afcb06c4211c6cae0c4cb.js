import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/main.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/main.css"
const __vite__css = ".container {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  height: 100vh;\n}\n\n.repl-history {\n  flex: 1 auto;\n  max-height: 55vh;\n  overflow-y: auto;\n  width: 100%;\n}\n\n.repl-input {\n  flex: 0 auto;\n  height: 10vh;\n  width: 100%;\n}\n\n.repl-command-box {\n  flex: 0 auto;\n  width: 90%;\n  max-width: 100%;\n}\ntable,\ntd {\n  border: 1px solid white;\n  margin: auto;\n  border-collapse: collapse;\n  border: 2px solid rgb(200, 200, 200);\n  font-family: sans-serif;\n  border: 1px solid rgb(190, 190, 190);\n  padding: 5px 10px;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))