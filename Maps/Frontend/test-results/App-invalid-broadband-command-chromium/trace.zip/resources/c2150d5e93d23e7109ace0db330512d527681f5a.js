import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ControlledInput.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/main.css";
export function ControlledInput({
  value,
  setValue,
  ariaLabel,
  onKeyDown
}) {
  return /* @__PURE__ */ jsxDEV("input", { type: "text", className: "repl-command-box", value, placeholder: "Enter command here!", "aria-label": ariaLabel, onChange: (ev) => setValue(ev.target.value), onKeyDown }, void 0, false, {
    fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/ControlledInput.tsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JNO0FBaEJOLE9BQU8sb0JBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBY1YsZ0JBQVNBLGdCQUFnQjtBQUFBLEVBQUNDO0FBQUFBLEVBQU9DO0FBQUFBLEVBQVVDO0FBQUFBLEVBQVdDO0FBQStCLEdBQUc7QUFDN0YsU0FDRSx1QkFBQyxXQUNDLE1BQUssUUFDTCxXQUFVLG9CQUNWLE9BQ0EsYUFBWSx1QkFDWixjQUFZRCxXQUNaLFVBQVdFLFFBQU9ILFNBQVNHLEdBQUdDLE9BQU9MLEtBQUssR0FDMUMsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUM7QUFFTDtBQUFDTSxLQVplUDtBQUFlLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDb250cm9sbGVkSW5wdXQiLCJ2YWx1ZSIsInNldFZhbHVlIiwiYXJpYUxhYmVsIiwib25LZXlEb3duIiwiZXYiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbnRyb2xsZWRJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuL21haW4uY3NzJztcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiB9IGZyb20gJ3JlYWN0JztcblxuLyoqXG4gKiBIZXJlLCB3ZSBzZXQgdXAgdGhlIGNvbW1hbmQgYm94IGFuZCBzZXQgYSBsYWJlbCBmb3IgaXQuXG4gKi9cblxuaW50ZXJmYWNlIENvbnRyb2xsZWRJbnB1dFByb3BzIHtcbiAgICB2YWx1ZTogc3RyaW5nLCBcbiAgICBzZXRWYWx1ZTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nPj4sXG4gICAgYXJpYUxhYmVsOiBzdHJpbmcsXG4gICAgb25LZXlEb3duPzooZXZlbnQ6IFJlYWN0LktleWJvYXJkRXZlbnQgPEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB2b2lkXG4gIH1cblxuICBleHBvcnQgZnVuY3Rpb24gQ29udHJvbGxlZElucHV0KHt2YWx1ZSwgc2V0VmFsdWUsIGFyaWFMYWJlbCwgb25LZXlEb3dufTogQ29udHJvbGxlZElucHV0UHJvcHMpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGlucHV0XG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgY2xhc3NOYW1lPVwicmVwbC1jb21tYW5kLWJveFwiXG4gICAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBjb21tYW5kIGhlcmUhXCJcbiAgICAgICAgYXJpYS1sYWJlbD17YXJpYUxhYmVsfVxuICAgICAgICBvbkNoYW5nZT17KGV2KSA9PiBzZXRWYWx1ZShldi50YXJnZXQudmFsdWUpfVxuICAgICAgICBvbktleURvd249e29uS2V5RG93bn1cbiAgICAgID48L2lucHV0PlxuICAgICk7XG4gIH0iXSwiZmlsZSI6Ii9Vc2Vycy9mcmFuY2VzY2FlbGlhL0RvY3VtZW50cy9DUzMyL21hcHMtZHNlZGFyb3UtZmVsaWEvTWFwcy9Gcm9udGVuZC9zcmMvQ29udHJvbGxlZElucHV0LnRzeCJ9