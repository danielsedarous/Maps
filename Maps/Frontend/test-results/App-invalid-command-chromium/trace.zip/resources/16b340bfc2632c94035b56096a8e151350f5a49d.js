import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZVMIEU5R.js?v=d07f8812";
import "/node_modules/.vite/deps/chunk-UXIASGQL.js?v=d07f8812";
export default require_react();
//# sourceMappingURL=react.js.map
