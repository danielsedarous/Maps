import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/REPLInput.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=d07f8812"; const useState = __vite__cjsImport4_react["useState"]; const useEffect = __vite__cjsImport4_react["useEffect"];
import { ControlledInput } from "/src/ControlledInput.tsx";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  var splitString;
  async function handleSubmit(commandString2) {
    splitString = splitIntoWords(commandString2);
    if (splitString[0] == "broadband") {
      var broadbandResult = await broadband(splitString);
      if (splitString.length == 3) {
        props.setResult(broadbandResult);
      } else {
        props.setResult([["Please enter a valid broadband command: broadband <state> <county>"]]);
      }
    } else if (splitString[0] == "highlight") {
      const highlightLength = (await highlight(splitString)).features.length;
      props.setHighlightResult((await highlight(splitString)).features);
      console.log("highlight length:" + highlightLength);
      console.log("highlight result:" + props.highlightResult);
      if (splitString.length > 1 && highlightLength > 0) {
        await props.setResult([["Search successful! Look on your map for the highlighted areas!"]]);
      } else {
        await props.setResult([["No results for your area description, please try another one and make sure your format is: highlight <area description>"]]);
      }
    } else {
      await props.setResult([["Please enter a valid command (broadband <state> <county> or highlight <area description>)"]]);
    }
  }
  useEffect(() => {
    let finalResult = props.Result;
    var resultTable = CSVToTable(finalResult);
    props.setHistory([resultTable]);
    setCommandString("");
  }, [props.Result]);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", children: /* @__PURE__ */ jsxDEV("fieldset", { children: [
    /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLInput.tsx",
      lineNumber: 49,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input", onKeyDown: handleKeyDown }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLInput.tsx",
      lineNumber: 50,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLInput.tsx",
    lineNumber: 48,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLInput.tsx",
    lineNumber: 47,
    columnNumber: 10
  }, this);
  function splitIntoWords(input) {
    const regex = /<([^>]+)>|[^\s]+/g;
    const results = [];
    let match;
    while ((match = regex.exec(input)) !== null) {
      results.push(match[1] || match[0]);
    }
    return results;
  }
  function CSVToTable(data) {
    return /* @__PURE__ */ jsxDEV("table", { "aria-label": "Result Table", children: /* @__PURE__ */ jsxDEV("tbody", { children: data.map((row) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell) => /* @__PURE__ */ jsxDEV("td", { "aria-label": cell, children: [
      " ",
      cell,
      " "
    ] }, void 0, true, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLInput.tsx",
      lineNumber: 78,
      columnNumber: 32
    }, this)) }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLInput.tsx",
      lineNumber: 77,
      columnNumber: 28
    }, this)) }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLInput.tsx",
      lineNumber: 76,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLInput.tsx",
      lineNumber: 75,
      columnNumber: 12
    }, this);
  }
  function handleKeyDown(event) {
    const historyWindow = document.getElementById("replHistoryId");
    if (event.key === "Enter") {
      handleSubmit(commandString);
    }
  }
  async function broadband(args) {
    return fetch("http://localhost:1234/broadband?state=" + args[1] + "&county=" + args[2]).then((r) => r.json()).then((response) => {
      var answer;
      console.log("response type" + response.type);
      if (response.type == "success") {
        answer = [["Broadband percentage for " + response.data[1][0] + ": " + response.data[1][1]]];
      } else {
        answer = [["Broadband error - check server API connection or ensure provided state and county are valid"]];
      }
      return answer;
    });
  }
  async function highlight(args) {
    return fetch("http://localhost:1234/mapsKeyWord?Area=" + args[1]).then((r) => r.json()).then((response) => {
      let parseAnswer;
      var answer;
      answer = response.data;
      parseAnswer = JSON.parse(answer);
      console.log(parseAnswer);
      return parseAnswer;
    });
  }
}
_s(REPLInput, "P2v7EMLswoBrnYy7zBWx5CmeYeY=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEVROzs7Ozs7Ozs7Ozs7Ozs7O0FBMUVSLE9BQU87QUFDUCxTQUlFQSxVQUNBQyxpQkFDSztBQUNQLFNBQVNDLHVCQUF1QjtBQWN6QixnQkFBU0MsVUFBVUMsT0FBdUI7QUFBQUMsS0FBQTtBQUMvQyxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJUCxTQUFpQixFQUFFO0FBQzdELE1BQUlRO0FBRUosaUJBQWVDLGFBQWFILGdCQUF1QjtBQUNqREUsa0JBQWNFLGVBQWVKLGNBQWE7QUFDMUMsUUFBSUUsWUFBWSxDQUFDLEtBQUssYUFBYTtBQUNqQyxVQUFJRyxrQkFBa0IsTUFBTUMsVUFBVUosV0FBVztBQUNqRCxVQUFJQSxZQUFZSyxVQUFVLEdBQUc7QUFDM0JULGNBQU1VLFVBQVVILGVBQWU7QUFBQSxNQUNqQyxPQUFPO0FBQ0xQLGNBQU1VLFVBQVUsQ0FBQyxDQUFDLG9FQUFvRSxDQUFDLENBQUM7QUFBQSxNQUMxRjtBQUFBLElBQ0YsV0FBV04sWUFBWSxDQUFDLEtBQUssYUFBYTtBQUN4QyxZQUFNTyxtQkFBMkIsTUFBTUMsVUFBVVIsV0FBVyxHQUFHUyxTQUM1REo7QUFDSFQsWUFBTWMsb0JBQW9CLE1BQU1GLFVBQVVSLFdBQVcsR0FBR1MsUUFBUTtBQUNoRUUsY0FBUUMsSUFBSSxzQkFBc0JMLGVBQWU7QUFDakRJLGNBQVFDLElBQUksc0JBQXNCaEIsTUFBTWlCLGVBQWU7QUFFdkQsVUFBSWIsWUFBWUssU0FBUyxLQUFLRSxrQkFBa0IsR0FBRztBQUVqRCxjQUFNWCxNQUFNVSxVQUFVLENBQ3BCLENBQUMsZ0VBQWdFLENBQUMsQ0FDbkU7QUFBQSxNQUNILE9BQU87QUFDTCxjQUFNVixNQUFNVSxVQUFVLENBQ3BCLENBQ0UseUhBQXlILENBQzFILENBQ0Y7QUFBQSxNQUNIO0FBQUEsSUFDRixPQUFPO0FBQ0wsWUFBTVYsTUFBTVUsVUFBVSxDQUNwQixDQUNFLDJGQUEyRixDQUM1RixDQUNGO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQWIsWUFBVSxNQUFNO0FBQ2QsUUFBSXFCLGNBQWNsQixNQUFNbUI7QUFDeEIsUUFBSUMsY0FBY0MsV0FBV0gsV0FBVztBQUN4Q2xCLFVBQU1zQixXQUFXLENBQUNGLFdBQVcsQ0FBQztBQUU5QmpCLHFCQUFpQixFQUFFO0FBQUEsRUFDckIsR0FBRyxDQUFDSCxNQUFNbUIsTUFBTSxDQUFDO0FBRWpCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsY0FDQztBQUFBLDJCQUFDLFlBQU8sZ0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QjtBQUFBLElBQ3hCLHVCQUFDLG1CQUNDLE9BQU9qQixlQUNQLFVBQVVDLGtCQUNWLFdBQVcsaUJBQ1gsV0FBV29CLGlCQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJMkI7QUFBQSxPQU43QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFjRixXQUFTakIsZUFBZWtCLE9BQXlCO0FBQy9DLFVBQU1DLFFBQVE7QUFDZCxVQUFNQyxVQUFvQjtBQUMxQixRQUFJQztBQUNKLFlBQVFBLFFBQVFGLE1BQU1HLEtBQUtKLEtBQUssT0FBTyxNQUFNO0FBQzNDRSxjQUFRRyxLQUFLRixNQUFNLENBQUMsS0FBS0EsTUFBTSxDQUFDLENBQUM7QUFBQSxJQUNuQztBQUNBLFdBQU9EO0FBQUFBLEVBQ1Q7QUFFQSxXQUFTTCxXQUFXUyxNQUFrQjtBQUNwQyxXQUNFLHVCQUFDLFdBQU0sY0FBVyxnQkFDaEIsaUNBQUMsV0FDRUEsZUFBS0MsSUFBS0MsU0FDVCx1QkFBQyxRQUNFQSxjQUFJRCxJQUFLRSxVQUNSLHVCQUFDLFFBQUcsY0FBWUEsTUFBTTtBQUFBO0FBQUEsTUFBRUE7QUFBQUEsTUFBSztBQUFBLFNBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEIsQ0FDL0IsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUEsQ0FDRCxLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLEVBRUo7QUFPQSxXQUFTVixjQUFjVyxPQUE4QztBQUNuRSxVQUFNQyxnQkFBZ0JDLFNBQVNDLGVBQWUsZUFBZTtBQUM3RCxRQUFJSCxNQUFNSSxRQUFRLFNBQVM7QUFDekJqQyxtQkFBYUgsYUFBYTtBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUVBLGlCQUFlTSxVQUFVK0IsTUFBcUM7QUFDNUQsV0FBT0MsTUFDTCwyQ0FBMkNELEtBQUssQ0FBQyxJQUFJLGFBQWFBLEtBQUssQ0FBQyxDQUMxRSxFQUNHRSxLQUFNQyxPQUFNQSxFQUFFQyxLQUFLLENBQUMsRUFDcEJGLEtBQU1HLGNBQWE7QUFDbEIsVUFBSUM7QUFDSjlCLGNBQVFDLElBQUksa0JBQWtCNEIsU0FBU0UsSUFBSTtBQUMzQyxVQUFJRixTQUFTRSxRQUFRLFdBQVc7QUFFOUJELGlCQUFTLENBQ1AsQ0FDRSw4QkFDRUQsU0FBU2QsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUNsQixPQUNBYyxTQUFTZCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FDdEI7QUFBQSxNQUVMLE9BQU87QUFDTGUsaUJBQVMsQ0FDUCxDQUNFLDZGQUE2RixDQUM5RjtBQUFBLE1BRUw7QUFDQSxhQUFPQTtBQUFBQSxJQUNULENBQUM7QUFBQSxFQUNMO0FBRUEsaUJBQWVqQyxVQUFVMkIsTUFBb0Q7QUFDM0UsV0FBT0MsTUFBTSw0Q0FBNENELEtBQUssQ0FBQyxDQUFDLEVBQzdERSxLQUFNQyxPQUFNQSxFQUFFQyxLQUFLLENBQUMsRUFDcEJGLEtBQU1HLGNBQWE7QUFDbEIsVUFBSUc7QUFDSixVQUFJRjtBQUNKQSxlQUFTRCxTQUFTZDtBQUNsQmlCLG9CQUFjQyxLQUFLQyxNQUFNSixNQUFNO0FBQy9COUIsY0FBUUMsSUFBSStCLFdBQVc7QUFDdkIsYUFBT0E7QUFBQUEsSUFDVCxDQUFDO0FBQUEsRUFDTDtBQUNGO0FBQUM5QyxHQXpKZUYsV0FBUztBQUFBbUQsS0FBVG5EO0FBQVMsSUFBQW1EO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkNvbnRyb2xsZWRJbnB1dCIsIlJFUExJbnB1dCIsInByb3BzIiwiX3MiLCJjb21tYW5kU3RyaW5nIiwic2V0Q29tbWFuZFN0cmluZyIsInNwbGl0U3RyaW5nIiwiaGFuZGxlU3VibWl0Iiwic3BsaXRJbnRvV29yZHMiLCJicm9hZGJhbmRSZXN1bHQiLCJicm9hZGJhbmQiLCJsZW5ndGgiLCJzZXRSZXN1bHQiLCJoaWdobGlnaHRMZW5ndGgiLCJoaWdobGlnaHQiLCJmZWF0dXJlcyIsInNldEhpZ2hsaWdodFJlc3VsdCIsImNvbnNvbGUiLCJsb2ciLCJoaWdobGlnaHRSZXN1bHQiLCJmaW5hbFJlc3VsdCIsIlJlc3VsdCIsInJlc3VsdFRhYmxlIiwiQ1NWVG9UYWJsZSIsInNldEhpc3RvcnkiLCJoYW5kbGVLZXlEb3duIiwiaW5wdXQiLCJyZWdleCIsInJlc3VsdHMiLCJtYXRjaCIsImV4ZWMiLCJwdXNoIiwiZGF0YSIsIm1hcCIsInJvdyIsImNlbGwiLCJldmVudCIsImhpc3RvcnlXaW5kb3ciLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwia2V5IiwiYXJncyIsImZldGNoIiwidGhlbiIsInIiLCJqc29uIiwicmVzcG9uc2UiLCJhbnN3ZXIiLCJ0eXBlIiwicGFyc2VBbnN3ZXIiLCJKU09OIiwicGFyc2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi9tYWluLmNzc1wiO1xuaW1wb3J0IHtcbiAgRGlzcGF0Y2gsXG4gIFJlYWN0RWxlbWVudCxcbiAgU2V0U3RhdGVBY3Rpb24sXG4gIHVzZVN0YXRlLFxuICB1c2VFZmZlY3QsXG59IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ29udHJvbGxlZElucHV0IH0gZnJvbSBcIi4vQ29udHJvbGxlZElucHV0XCI7XG5leHBvcnQgaW50ZXJmYWNlIFJFUExJbnB1dFByb3BzIHtcbiAgaGlzdG9yeTogUmVhY3RFbGVtZW50W107XG4gIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPFJlYWN0RWxlbWVudFtdPj47XG4gIFJlc3VsdDogc3RyaW5nW11bXTtcbiAgc2V0UmVzdWx0OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmdbXVtdPj47XG4gIGhpZ2hsaWdodFJlc3VsdDogR2VvSlNPTi5GZWF0dXJlW107XG4gIHNldEhpZ2hsaWdodFJlc3VsdDogRGlzcGF0Y2g8XG4gICAgU2V0U3RhdGVBY3Rpb248XG4gICAgICBHZW9KU09OLkZlYXR1cmU8R2VvSlNPTi5HZW9tZXRyeSwgR2VvSlNPTi5HZW9Kc29uUHJvcGVydGllcz5bXVxuICAgID5cbiAgPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFJFUExJbnB1dChwcm9wczogUkVQTElucHV0UHJvcHMpIHtcbiAgY29uc3QgW2NvbW1hbmRTdHJpbmcsIHNldENvbW1hbmRTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgdmFyIHNwbGl0U3RyaW5nOiBzdHJpbmdbXTtcblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZzogc3RyaW5nKSB7XG4gICAgc3BsaXRTdHJpbmcgPSBzcGxpdEludG9Xb3Jkcyhjb21tYW5kU3RyaW5nKTtcbiAgICBpZiAoc3BsaXRTdHJpbmdbMF0gPT0gXCJicm9hZGJhbmRcIikge1xuICAgICAgdmFyIGJyb2FkYmFuZFJlc3VsdCA9IGF3YWl0IGJyb2FkYmFuZChzcGxpdFN0cmluZyk7XG4gICAgICBpZiAoc3BsaXRTdHJpbmcubGVuZ3RoID09IDMpIHtcbiAgICAgICAgcHJvcHMuc2V0UmVzdWx0KGJyb2FkYmFuZFJlc3VsdCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwcm9wcy5zZXRSZXN1bHQoW1tcIlBsZWFzZSBlbnRlciBhIHZhbGlkIGJyb2FkYmFuZCBjb21tYW5kOiBicm9hZGJhbmQgPHN0YXRlPiA8Y291bnR5PlwiXV0pO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoc3BsaXRTdHJpbmdbMF0gPT0gXCJoaWdobGlnaHRcIikge1xuICAgICAgY29uc3QgaGlnaGxpZ2h0TGVuZ3RoOiBudW1iZXIgPSAoYXdhaXQgaGlnaGxpZ2h0KHNwbGl0U3RyaW5nKSkuZmVhdHVyZXNcbiAgICAgICAgLmxlbmd0aDtcbiAgICAgIHByb3BzLnNldEhpZ2hsaWdodFJlc3VsdCgoYXdhaXQgaGlnaGxpZ2h0KHNwbGl0U3RyaW5nKSkuZmVhdHVyZXMpO1xuICAgICAgY29uc29sZS5sb2coXCJoaWdobGlnaHQgbGVuZ3RoOlwiICsgaGlnaGxpZ2h0TGVuZ3RoKTtcbiAgICAgIGNvbnNvbGUubG9nKFwiaGlnaGxpZ2h0IHJlc3VsdDpcIiArIHByb3BzLmhpZ2hsaWdodFJlc3VsdCk7XG5cbiAgICAgIGlmIChzcGxpdFN0cmluZy5sZW5ndGggPiAxICYmIGhpZ2hsaWdodExlbmd0aCA+IDApIHtcbiAgICAgICAgLy8gcHJvcHMuc2V0SGlnaGxpZ2h0UmVzdWx0KCgoYXdhaXQgaGlnaGxpZ2h0KHNwbGl0U3RyaW5nKSkuZmVhdHVyZXMpKTtcbiAgICAgICAgYXdhaXQgcHJvcHMuc2V0UmVzdWx0KFtcbiAgICAgICAgICBbXCJTZWFyY2ggc3VjY2Vzc2Z1bCEgTG9vayBvbiB5b3VyIG1hcCBmb3IgdGhlIGhpZ2hsaWdodGVkIGFyZWFzIVwiXSxcbiAgICAgICAgXSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhd2FpdCBwcm9wcy5zZXRSZXN1bHQoW1xuICAgICAgICAgIFtcbiAgICAgICAgICAgIFwiTm8gcmVzdWx0cyBmb3IgeW91ciBhcmVhIGRlc2NyaXB0aW9uLCBwbGVhc2UgdHJ5IGFub3RoZXIgb25lIGFuZCBtYWtlIHN1cmUgeW91ciBmb3JtYXQgaXM6IGhpZ2hsaWdodCA8YXJlYSBkZXNjcmlwdGlvbj5cIixcbiAgICAgICAgICBdLFxuICAgICAgICBdKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgcHJvcHMuc2V0UmVzdWx0KFtcbiAgICAgICAgW1xuICAgICAgICAgIFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgY29tbWFuZCAoYnJvYWRiYW5kIDxzdGF0ZT4gPGNvdW50eT4gb3IgaGlnaGxpZ2h0IDxhcmVhIGRlc2NyaXB0aW9uPilcIixcbiAgICAgICAgXSxcbiAgICAgIF0pO1xuICAgIH1cbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGZpbmFsUmVzdWx0ID0gcHJvcHMuUmVzdWx0O1xuICAgIHZhciByZXN1bHRUYWJsZSA9IENTVlRvVGFibGUoZmluYWxSZXN1bHQpO1xuICAgIHByb3BzLnNldEhpc3RvcnkoW3Jlc3VsdFRhYmxlXSk7XG5cbiAgICBzZXRDb21tYW5kU3RyaW5nKFwiXCIpO1xuICB9LCBbcHJvcHMuUmVzdWx0XSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaW5wdXRcIj5cbiAgICAgIDxmaWVsZHNldD5cbiAgICAgICAgPGxlZ2VuZD5FbnRlciBhIGNvbW1hbmQ6PC9sZWdlbmQ+XG4gICAgICAgIDxDb250cm9sbGVkSW5wdXRcbiAgICAgICAgICB2YWx1ZT17Y29tbWFuZFN0cmluZ31cbiAgICAgICAgICBzZXRWYWx1ZT17c2V0Q29tbWFuZFN0cmluZ31cbiAgICAgICAgICBhcmlhTGFiZWw9e1wiQ29tbWFuZCBpbnB1dFwifVxuICAgICAgICAgIG9uS2V5RG93bj17aGFuZGxlS2V5RG93bn1cbiAgICAgICAgLz5cbiAgICAgIDwvZmllbGRzZXQ+XG4gICAgPC9kaXY+XG4gICk7XG5cbiAgLyoqXG4gICAqU3BsaXQgaW50byB3b3JkcyBpcyBhIGhlbHBlciBmdW5jdGlvbiB0aGF0IGlzIHVzZWQgdG8gdHVybiB0aGUgaW5wdXQgdGhhdCB0aGUgdXNlciBwcm92aWRlcyBpbiB0aGVcbiAgICpjb21tYW5kIGJveCBpbnRvIHVzYWJsZSBkYXRhIHRoYXQgdGhlIGFwcGxpY2F0aW9uIGNhbiBkZWFsIHdpdGguIEEgcmVnZXggaXMgdXNlZCB0aGF0IGlzXG4gICAqbG9va2luZyBmb3IgdHdvIGNvbmRpdGlvbnMgdG8g4oCcZmlsdGVy4oCdIHRoZSBpbnB1dCB0ZXh0IG9uLiBJZiB0aGUgdXNlciB3b3VsZCBsaWtlIHRvIHByb3ZpZGUgdGVybXNcbiAgICpjb250YWluaW5nIG1vcmUgdGhhbiBvbmUgd29yZCwgYW5nbGUgYnJhY2tldHMgYXJlIHVzZWQgdG8gY29udGFpbiB0aGUgZW50aXJlIHRlcm0uIEFzaWRlIGZyb21cbiAgICp0ZXh0IHdpdGhpbiB0aGVzZSBhbmdsZSBicmFja2V0cyBob3dldmVyLCBzcGFjZXMgYXJlIHVzZWQgdG8gc2VwYXJhdGUgdGhlIHRlcm1zLCB3aGljaCBhcmVcbiAgICphZGRlZCB0byBhbiBhcnJheSBvZiBzdHJpbmdzLiBJdCBpcyB0aGlzIGFycmF5IHRoYXQgaXMgdXNlZCB0byBjaGVjayBmb3IgaW5kaXZpZHVhbCBjb21tYW5kcyBhbmRcbiAgICp2YWx1ZXMgcGFzc2VkIGluIGJ5IHRoZSB1c2VyIHBlcmZvcm1lZCBieSBvdGhlciBmdW5jdGlvbnMgdGhyb3VnaG91dCB0aGUgYXBwbGljYXRpb24uXG4gICAqL1xuXG4gIC8vIFJlZ2V4IHBhdHRlcm4gZm91bmQgb24gU3RhY2tPdmVyZmxvdy5cbiAgZnVuY3Rpb24gc3BsaXRJbnRvV29yZHMoaW5wdXQ6IHN0cmluZyk6IHN0cmluZ1tdIHtcbiAgICBjb25zdCByZWdleCA9IC88KFtePl0rKT58W15cXHNdKy9nO1xuICAgIGNvbnN0IHJlc3VsdHM6IHN0cmluZ1tdID0gW107XG4gICAgbGV0IG1hdGNoO1xuICAgIHdoaWxlICgobWF0Y2ggPSByZWdleC5leGVjKGlucHV0KSkgIT09IG51bGwpIHtcbiAgICAgIHJlc3VsdHMucHVzaChtYXRjaFsxXSB8fCBtYXRjaFswXSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHRzO1xuICB9XG5cbiAgZnVuY3Rpb24gQ1NWVG9UYWJsZShkYXRhOiBzdHJpbmdbXVtdKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDx0YWJsZSBhcmlhLWxhYmVsPVwiUmVzdWx0IFRhYmxlXCI+XG4gICAgICAgIDx0Ym9keT5cbiAgICAgICAgICB7ZGF0YS5tYXAoKHJvdykgPT4gKFxuICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICB7cm93Lm1hcCgoY2VsbCkgPT4gKFxuICAgICAgICAgICAgICAgIDx0ZCBhcmlhLWxhYmVsPXtjZWxsfT4ge2NlbGx9IDwvdGQ+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC90Ym9keT5cbiAgICAgIDwvdGFibGU+XG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGZ1bmN0aW9uIGlzIHJlc3BvbnNpYmxlIGZvciBjaGVja2luZyBmb3Iga2V5Ym9hcmQgZXZlbnRzIGV4ZWN1dGVkIGJ5IHRoZSB1c2VyLlxuICAgKiBXaGVuIHRoZSBlbnRlciBrZXkgaXMgcHJlc3NlZCwgdGhlIGhhbmRsZVN1Ym1pdCBmdW5jdGlvbiBpcyBjYWxsZWQgKGFzIGlmIHRoZSBidXR0b24gd2FzIHByZXNzZWQpLlxuICAgKiBAcGFyYW0gZXZlbnRcbiAgICovXG4gIGZ1bmN0aW9uIGhhbmRsZUtleURvd24oZXZlbnQ6IFJlYWN0LktleWJvYXJkRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pIHtcbiAgICBjb25zdCBoaXN0b3J5V2luZG93ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJyZXBsSGlzdG9yeUlkXCIpO1xuICAgIGlmIChldmVudC5rZXkgPT09IFwiRW50ZXJcIikge1xuICAgICAgaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmcpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGJyb2FkYmFuZChhcmdzOiBzdHJpbmdbXSk6IFByb21pc2U8c3RyaW5nW11bXT4ge1xuICAgIHJldHVybiBmZXRjaChcbiAgICAgIFwiaHR0cDovL2xvY2FsaG9zdDoxMjM0L2Jyb2FkYmFuZD9zdGF0ZT1cIiArIGFyZ3NbMV0gKyBcIiZjb3VudHk9XCIgKyBhcmdzWzJdXG4gICAgKVxuICAgICAgLnRoZW4oKHIpID0+IHIuanNvbigpKVxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgIHZhciBhbnN3ZXI7XG4gICAgICAgIGNvbnNvbGUubG9nKFwicmVzcG9uc2UgdHlwZVwiICsgcmVzcG9uc2UudHlwZSk7XG4gICAgICAgIGlmIChyZXNwb25zZS50eXBlID09IFwic3VjY2Vzc1wiKSB7XG4gICAgICAgICAgLy8gYW5zd2VyID0gcmVzcG9uc2UuZGF0YTtcbiAgICAgICAgICBhbnN3ZXIgPSBbXG4gICAgICAgICAgICBbXG4gICAgICAgICAgICAgIFwiQnJvYWRiYW5kIHBlcmNlbnRhZ2UgZm9yIFwiICtcbiAgICAgICAgICAgICAgICByZXNwb25zZS5kYXRhWzFdWzBdICtcbiAgICAgICAgICAgICAgICBcIjogXCIgK1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlLmRhdGFbMV1bMV0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgIF07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgYW5zd2VyID0gW1xuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICBcIkJyb2FkYmFuZCBlcnJvciAtIGNoZWNrIHNlcnZlciBBUEkgY29ubmVjdGlvbiBvciBlbnN1cmUgcHJvdmlkZWQgc3RhdGUgYW5kIGNvdW50eSBhcmUgdmFsaWRcIixcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYW5zd2VyO1xuICAgICAgfSk7XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBoaWdobGlnaHQoYXJnczogc3RyaW5nW10pOiBQcm9taXNlPEdlb0pTT04uRmVhdHVyZUNvbGxlY3Rpb24+IHtcbiAgICByZXR1cm4gZmV0Y2goXCJodHRwOi8vbG9jYWxob3N0OjEyMzQvbWFwc0tleVdvcmQ/QXJlYT1cIiArIGFyZ3NbMV0pXG4gICAgICAudGhlbigocikgPT4gci5qc29uKCkpXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcbiAgICAgICAgbGV0IHBhcnNlQW5zd2VyOiBHZW9KU09OLkZlYXR1cmVDb2xsZWN0aW9uO1xuICAgICAgICB2YXIgYW5zd2VyO1xuICAgICAgICBhbnN3ZXIgPSByZXNwb25zZS5kYXRhO1xuICAgICAgICBwYXJzZUFuc3dlciA9IEpTT04ucGFyc2UoYW5zd2VyKTtcbiAgICAgICAgY29uc29sZS5sb2cocGFyc2VBbnN3ZXIpO1xuICAgICAgICByZXR1cm4gcGFyc2VBbnN3ZXI7XG4gICAgICB9KTtcbiAgfVxufVxuIl0sImZpbGUiOiIvVXNlcnMvZnJhbmNlc2NhZWxpYS9Eb2N1bWVudHMvQ1MzMi9tYXBzLWRzZWRhcm91LWZlbGlhL01hcHMvRnJvbnRlbmQvc3JjL1JFUExJbnB1dC50c3gifQ==