import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ControlledInput.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/main.css";
export function ControlledInput({
  value,
  setValue,
  ariaLabel,
  onKeyDown
}) {
  return /* @__PURE__ */ jsxDEV("input", { type: "text", className: "repl-command-box", value, placeholder: "Enter command here!", "aria-label": ariaLabel, onChange: (ev) => setValue(ev.target.value), onKeyDown }, void 0, false, {
    fileName: "/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/ControlledInput.tsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/francescaelia/Documents/CS32/maps-dsedarou-felia/Maps/Frontend/src/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJJO0FBMUJKLE9BQU8sb0JBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBbUJaLGdCQUFTQSxnQkFBZ0I7QUFBQSxFQUM5QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDb0IsR0FBRztBQUN2QixTQUNFLHVCQUFDLFdBQ0MsTUFBSyxRQUNMLFdBQVUsb0JBQ1YsT0FDQSxhQUFZLHVCQUNaLGNBQVlELFdBQ1osVUFBV0UsUUFBT0gsU0FBU0csR0FBR0MsT0FBT0wsS0FBSyxHQUMxQyxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQztBQUVMO0FBQUNNLEtBakJlUDtBQUFlLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDb250cm9sbGVkSW5wdXQiLCJ2YWx1ZSIsInNldFZhbHVlIiwiYXJpYUxhYmVsIiwib25LZXlEb3duIiwiZXYiLCJ0YXJnZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbnRyb2xsZWRJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi9tYWluLmNzc1wiO1xuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uIH0gZnJvbSBcInJlYWN0XCI7XG5cbi8qKlxuICogSGVyZSwgd2Ugc2V0IHVwIHRoZSBjb21tYW5kIGJveCBhbmQgc2V0IGEgbGFiZWwgZm9yIGl0LlxuICovXG5cbmludGVyZmFjZSBDb250cm9sbGVkSW5wdXRQcm9wcyB7XG4gIHZhbHVlOiBzdHJpbmc7XG4gIHNldFZhbHVlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PjtcbiAgYXJpYUxhYmVsOiBzdHJpbmc7XG4gIG9uS2V5RG93bj86IChldmVudDogUmVhY3QuS2V5Ym9hcmRFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4gdm9pZDtcbn1cblxuLyoqXG4gKiBzZXRzIHVwIGZ1bmN0aW9uYWxpdHkgZm9yIGNvbW1hbmQgbGluZSBib3hcbiAqIEBwYXJhbSBwYXJhbTBcbiAqIEByZXR1cm5zXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBDb250cm9sbGVkSW5wdXQoe1xuICB2YWx1ZSxcbiAgc2V0VmFsdWUsXG4gIGFyaWFMYWJlbCxcbiAgb25LZXlEb3duLFxufTogQ29udHJvbGxlZElucHV0UHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8aW5wdXRcbiAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgIGNsYXNzTmFtZT1cInJlcGwtY29tbWFuZC1ib3hcIlxuICAgICAgdmFsdWU9e3ZhbHVlfVxuICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBjb21tYW5kIGhlcmUhXCJcbiAgICAgIGFyaWEtbGFiZWw9e2FyaWFMYWJlbH1cbiAgICAgIG9uQ2hhbmdlPXsoZXYpID0+IHNldFZhbHVlKGV2LnRhcmdldC52YWx1ZSl9XG4gICAgICBvbktleURvd249e29uS2V5RG93bn1cbiAgICA+PC9pbnB1dD5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZyYW5jZXNjYWVsaWEvRG9jdW1lbnRzL0NTMzIvbWFwcy1kc2VkYXJvdS1mZWxpYS9NYXBzL0Zyb250ZW5kL3NyYy9Db250cm9sbGVkSW5wdXQudHN4In0=